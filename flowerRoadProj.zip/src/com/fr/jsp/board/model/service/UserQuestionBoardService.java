package com.fr.jsp.board.model.service;

public class UserQuestionBoardService {

}
