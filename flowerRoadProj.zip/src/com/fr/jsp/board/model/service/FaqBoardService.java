package com.fr.jsp.board.model.service;

public class FaqBoardService {

}
