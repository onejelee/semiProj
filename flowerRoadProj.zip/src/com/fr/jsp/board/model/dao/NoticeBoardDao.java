package com.fr.jsp.board.model.dao;

public class NoticeBoardDao {

}
