package com.fr.jsp.order.model.vo;

import java.util.Date;

public class Order {
	// 변수
	   private String order_num;
	   private String member_num;
	   private String product_num;
	   private Date ordered_date;
	   private Date reservation_date;
	   private String receiver_name;
	   private String receiver_address;
	   private String receiver_phone;
	   private String order_state_code;
}
