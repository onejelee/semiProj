package com.fr.jsp.order.model.service;

public class OrderService {

}
