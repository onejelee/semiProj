package com.fr.jsp.order.model.dao;

public class OrderDao {

}
