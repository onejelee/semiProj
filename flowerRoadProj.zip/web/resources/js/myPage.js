// 비밀번호 변경
function pwd(){
    location.href = "/flowerRoadProj/views/myPage/myPage_pwdChange.jsp";
}
// 정보 수정
function modify(){
    location.href = "/flowerRoadProj/views/myPage/myPage_infoModify.jsp";
}
// 탈퇴 하기
function withdrawal(){
    location.href = "/flowerRoadProj/views/myPage/myPage_memberWithdrawal.jsp";
}
// 카테고리-내 정보
function info(){
    location.href = "/flowerRoadProj/views/myPage/myPage_main.jsp"
}
// 회원 확인 취소 버튼
function rechkCancel(){
    location.href = "/flowerRoadProj/views/myPage/myPage_main.jsp"
}
// 카테고리 - 주문조회
function orderChk(){
    location.href = "/flowerRoadProj/views/myPage/orderCheck.jsp"
}
// 카테고리 - 관심상품
function favorite(){
    location.href = "/flowerRoadProj/views/myPage/favorite.jsp"
}
// 카테고리 - 1:1 문의
function oneToOne(){
    location.href = "/flowerRoadProj/views/myPage/1on1Page_board.jsp"
}
// 1:1 문의하기
function question(){
    location.href = "/flowerRoadProj/views/myPage/1on1Page_Question.jsp"
}
// 1:1 게시판 목록보기
function viewBoard(){
    location.href = "/flowerRoadProj/views/myPage/1on1Page_board.jsp"
}
